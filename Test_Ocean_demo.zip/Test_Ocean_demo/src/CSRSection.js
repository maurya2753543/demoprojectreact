// src/components/CSRSection.js
import React from 'react';
import './CSRSection.css'; // Import your CSS file for styling
import { Button } from 'react-bootstrap'; // Import Button from react-bootstrap

const csrData = [
  {
    imgSrc: 'https://oceanicpharmachem.com/upload/csr_gallery/medium/1586172946artical-Small.jpg',
    alt: 'The world is reeling under the pandemic of Covid-19',
    title: 'The world is reeling under the pandemic of Covid-19',
    description: 'The world is currently reeling under the pandemic of Covid-19. The UN Secretary-General has warned that the world faces the most challenging crisis since World War II, confronting a ...',
    link: 'https://oceanicpharmachem.com/csr-deatil/the-world-is-reeling-under-the-pandemic-of-covid-19'
  },
  {
    imgSrc: 'https://oceanicpharmachem.com/upload/csr_gallery/medium/1578475441banner.jpg',
    alt: 'Lending a helping hand to those in distress due to severe cold wave',
    title: 'Lending a helping hand to those in distress due to severe cold wave',
    description: 'Oceanic Pharmachem Pvt. Ltd, CSR policy has always been at the forefront when it comes to giving back to society. The company believes that investing in charitable and philanthropic ...',
    link: 'https://oceanicpharmachem.com/csr-deatil/lending-a-helping-hand-to-those-in-distress-due-to-severe-cold-wave'
  },
  {
    imgSrc: 'https://oceanicpharmachem.com/upload/csr_gallery/medium/1580284662The-Green-Imperative.jpg',
    alt: 'The Green Imperative',
    title: 'The Green Imperative',
    description: 'Kids skipping school may not be able to change the world, but the climate-change school strikes started by Swedish teenager Greta Thunberg in November 2018 show how the sustainability debate ...',
    link: 'https://oceanicpharmachem.com/csr-deatil/the-green-imperative'
  }
];

const CSRSection = () => {
  return (
    <>          
     <h2 className="new_title_inside">CSR</h2>
    <div className="csr-block">
      <div className="container">
        <div className="wow slideInUp new_title" data-wow-delay="0.1s" data-wow-duration="1.2s">
        </div>
        <div className="row">
          {csrData.map((item, index) => (
            <div className="col-lg-4 col-md-4 col-sm-4 col-xs-12 column" key={index}>
              <div className="csr-box">
                <div className="thumb">
                  <img className="img-responsive" alt={item.alt} src={item.imgSrc} />
                </div>
                <div className="caption">
                  <h3 className="title">{item.title}</h3>
                  <p>{item.description}</p>
                  <Button className='News_more_btn_csr' >Read More</Button>

                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="learnmore-block text-center">
        <Button className='learn_more_btn_csr' >Learn More</Button>
        </div>
      </div>
    </div>
   
    </>
  );
};

export default CSRSection;
