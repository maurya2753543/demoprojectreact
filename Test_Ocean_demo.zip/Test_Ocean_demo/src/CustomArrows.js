// CustomArrows.js
import React from 'react';
import './CustomArrows.css';

export const PrevArrow = (props) => {
  const { onClick } = props;
  return (
    <button className="owl-nav-button owl-prev" onClick={onClick} aria-label="Previous">
      <span>‹</span>
    </button>
  );
};

export const NextArrow = (props) => {
  const { onClick } = props;
  return (
    <button className="owl-nav-button owl-next" onClick={onClick} aria-label="Next">
      <span>›</span>
    </button>
  );
};
