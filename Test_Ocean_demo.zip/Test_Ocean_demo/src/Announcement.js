import React, { } from 'react';
import './Announcement.css'; // Import the CSS file for styling

const Announcement = () => {
   

  return (
    <div>
      {/* Breadcrumb Navigation */}
      <div className="breads_anu">

      {/* Scrolling Announcement Message */}
      <div className="announcement-bar">
        <div className="scrolling-text">
        <p>Welcome to our latest announcements! Stay tuned for updates, events, and news. This is a scrolling announcement banner.</p>

          {/* You can replace this text with dynamic announcements */}
        </div>
      </div>
      </div>  

    </div>
  );
};

export default Announcement;
