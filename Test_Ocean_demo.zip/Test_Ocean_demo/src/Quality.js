import React from 'react';
import './Quality.css'; // Import the CSS file for styling
import { Button } from 'react-bootstrap'; // Import Button from react-bootstrap

const qualities = [
  {
    title: 'Regulatory Services',
    image: 'https://oceanicpharmachem.com/upload/quality/medium/1545391622quality01.png',
    description: 'A team of professionals, with significant experience within the pharmaceut...',
    link: 'https://oceanicpharmachem.com/quality/regulatory-services',
  },
  {
    title: 'Quality Assurance',
    image: 'https://oceanicpharmachem.com/upload/quality/medium/1545391591quality02.png',
    description: 'Quality is our strength and in order to maintain it at every stage of our ...',
    link: 'https://oceanicpharmachem.com/quality/quality-assurance-',
  },
  {
    title: 'Quality Control',
    image: 'https://oceanicpharmachem.com/upload/quality/medium/1545391552quality03.png',
    description: 'Oceanic Pharmachem Pvt Ltd is associated with state of-the-art FDA approve...',
    link: 'https://oceanicpharmachem.com/quality/quality-control-',
  },
  {
    title: 'Quality Policy',
    image: 'https://oceanicpharmachem.com/upload/quality/medium/1545124609quality06.png',
    description: 'Oceanic Pharmachem Pvt Ltd is committed to offer products and services.',
    link: 'https://oceanicpharmachem.com/quality/quality-policy',
  },
  // Add more items as needed
];

const Quality = () => {
  return (
    <ul className="quality-list">
      {qualities.map((quality, index) => (
        <li key={index} className={`quality-item quality-item-${index + 1}`}>
          <div
            className="qual_img"
            style={{ backgroundImage: `url(${quality.image})` }}
          ></div>
          <div className="qual_main_title">{quality.title}</div>
          <div className="qual_main_para">
            <p>{quality.description}</p>
          </div>
          <Button className='readmore-btn-quality' >Read More</Button>
        </li>
      ))}
    </ul>
  );
};

export default Quality;
