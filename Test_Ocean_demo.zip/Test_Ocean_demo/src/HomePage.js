import React, { useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './HomePage.css'; // Ensure this file exists and contains any custom styles you need
import { Modal, Button } from 'react-bootstrap'; // Import Modal and Button from react-bootstrap
import CounterCarousel from './CounterCarousel'; // Ensure this import path is correct
import Product from './Product';
import Quality from './Quality';
import EventGallery from './EventGallery';
import NewsAndBlogSlider from './NewsAndBlogSlider'; // Adjust the import path as necessary
import CSRSection from './CSRSection';
import EnquiryForm from './EnquiryForm';
import Footer from './Footer';
import ChatPopup from './ChatPopup';
import Announcement from './Announcement';



function HomePage() {
  useEffect(() => {
    // Initialize the carousel if not already initialized
    const carouselElement = document.querySelector('#myCarousel');
    if (carouselElement) {
      const carouselInstance = new window.bootstrap.Carousel(carouselElement, {
        interval: 3000, // Set the interval to 3000ms for automatic slide change
        ride: 'carousel' // Ensure that the carousel starts cycling automatically
      });

      // Optional: Clean up the instance if the component unmounts
      return () => {
        carouselInstance.dispose();
      };
    }
  }, []);

  return (
    <>
     <Announcement />   
    <div className="banner">
      <div id="myCarousel" className="carousel slide">
        {/* Indicators */}
        <ol className="carousel-indicators">
          <li data-bs-target="#myCarousel" data-bs-slide-to="0" className="active"></li>
          <li data-bs-target="#myCarousel" data-bs-slide-to="1"></li>
          <li data-bs-target="#myCarousel" data-bs-slide-to="2"></li>
          <li data-bs-target="#myCarousel" data-bs-slide-to="3"></li>
          <li data-bs-target="#myCarousel" data-bs-slide-to="4"></li>

        </ol>

        {/* Wrapper for slides */}
        <div className="carousel-inner" role="listbox">
          <div className="carousel-item active">
            <img src="https://oceanicpharmachem.com/upload/banner/medium/165290252916526877651652422380919016_1923565257 (1).png" alt="Celebrating 25 Years" />
            <div className="carousel-caption">
              <h3>Celebrating 25 Years</h3>
            </div>
          </div>
          <div className="carousel-item">
            <img src="https://oceanicpharmachem.com/upload/banner/medium/1579266676Inspire.jpg" alt="Inspire" />
            <div className="carousel-caption">
              <h3>Inspire</h3>
            </div>
          </div>
          <div className="carousel-item">
            <img src="https://oceanicpharmachem.com/upload/banner/medium/1579266908innovate.jpg" alt="Innovate" />
            <div className="carousel-caption">
              <h3>Innovate</h3>
            </div>
          </div>
          <div className="carousel-item">
            <img src="https://oceanicpharmachem.com/upload/banner/medium/1579266916ideate2.jpg" alt="Ideate" />
            <div className="carousel-caption">
              <h3>Ideate</h3>
            </div>
          </div>
          <div className="carousel-item">
            <img src="/image/company_at_glance.png" alt="Company Insights" />
            <div className="carousel-caption">
              <h3>Company Insights</h3>
            </div>
          </div>
        
        </div>
      </div>

      <div className="downarrow bounce">
        <a href="#about">
          <img src="https://oceanicpharmachem.com/site/views/images/down-arrow.png" alt="Down Arrow" />
        </a>
      </div>

      <div className="video-container" style={{ marginTop: '20px' }}>
        <video
          className="inner-video"
          id="video-block"
          width="100%"
          height="255"
          poster="https://oceanicpharmachem.com/site/views/images/welcome-video.jpg"
          controls
        >
          <source
            src="https://oceanicpharmachem.com/site/views/images/OceanicPharmachemPvtLtdCorporateVideo.mp4"
            type="video/mp4"
          />
          {/* Fallback text if the video is not supported */}
          Your browser does not support the video tag.
        </video>
        <div className="summary-block" >
        <p>
          Oceanic Pharmachem Pvt Ltd is certified as an ISO 9001:2015 company awarded by QA International Certification Ltd., UK. We have expertise for more than 52 years in catering exclusively to the pharmaceutical & fine chemicals requirements internationally.
        </p>
        <Button  className="know-more">
        Know More
          </Button>      

      </div>    
      <div className="Count-carousel">
      <CounterCarousel />
    </div>
  
      </div>
      <div>
           <Product />

        </div>
     <div className='Quality'>
     <Quality />
        </div>

        <div className='Event-Galary'>
     <EventGallery />
        </div>
        <div className="NewAndBlog">
      <NewsAndBlogSlider />
      </div>
      <div  className="CRSSection">
     
      <CSRSection />
      
    </div>    
      <EnquiryForm />
    
      <div>
        <div>
        <Footer />

        </div>
        <div>
        <ChatPopup />
        </div>
    </div>
    </div>
    </>
  );
}

export default HomePage;
