// src/pages/AboutUs.js

import React, { useEffect } from 'react';
import  './AboutUs.css';

const AboutUs = () => {
 
  return (
    <div>
      {/* Breadcrumb Navigation */}
      <div className="breads">
        <div className="container">
        <span>Home</span>
          <i className="fa fa-angle-right"></i> 
          <span><b>About Us</b></span>
        </div>
      </div>
      <div className="banner">
        <img 
          src="https://oceanicpharmachem.com/site/views/images/about-banner.jpg" 
          alt="About Us Banner" 
        />
      </div>
   
    </div>
  );
}

export default AboutUs;
