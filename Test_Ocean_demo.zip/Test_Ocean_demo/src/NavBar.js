// src/components/NavBar.js
import React, { useState } from 'react';
import './NavBar.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';
import { Modal, Button } from 'react-bootstrap';
import { useTranslation } from 'react-i18next'; // Import the useTranslation hook
import './i18n';
import { Link } from 'react-router-dom';


function NavBar() {
  const { t, i18n } = useTranslation(); // Destructure t and i18n from useTranslation
  const [showModal, setShowModal] = useState(false);
  const [showMenuDropdown, setShowMenuDropdown] = useState(false);

  // Function to handle language change
  const selectLanguage = (language) => {
    i18n.changeLanguage(language); // Change the language
  };

  // Function to open the modal
  const openModal = () => {
    setShowModal(true);
  };

  // Function to close the modal
  const closeModal = () => {
    setShowModal(false);
  };

  // Toggle menu dropdown
  const toggleMenuDropdown = () => {
    setShowMenuDropdown(!showMenuDropdown);
  };

  return (
    <>
      <nav className="navbar navbar-expand-lg bg-body-tertiary">
        <div className="container-fluid">
          <a className="navbar-brand" href="https://oceanicpharmachem.com">
            <img src="https://oceanicpharmachem.com/site/views/images/logo.png" alt="Oceanic Pharmachem" />
          </a>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav me-auto mb-2 mb-sm-0">
              <li className="nav-item">
              <Link className="nav-link active"  to="/">{t('home')}</Link>               

              </li>
              <li className="nav-item dropdown">
                <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  {t('about_us')}
                </a>
                <ul className="dropdown-menu">
                  <li>
                  <Link className="dropdown-item"  to="/about-us#about">{t('company_at_a_glance')}</Link>                      
                      </li>
                  <li><a className="dropdown-item" href="#">{t('the_beginnings')}</a></li>
                  <li><a className="dropdown-item" href="#">{t('global_presence')}</a></li>
                  <li><a className="dropdown-item" href="#">{t('whats_happening_nowadays')}</a></li>
                  <li><a className="dropdown-item" href="#">{t('our_strong_presence')}</a></li>
                </ul>
              </li>
              <ul className="navbar-nav">
      <li className="nav-item dropdown">
        <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          {t('products')}
        </a>
        <ul className="dropdown-menu">
          <li><a className="dropdown-item" href="#">{t('active_pharmaceutical_ingredient')}</a></li>
          <li><a className="dropdown-item" href="#">{t('veterinary_products')}</a></li>
          <li><a className="dropdown-item" href="#">{t('impurities')}</a></li>
          <li><a className="dropdown-item" href="#">{t('bulk_drug_intermediates')}</a></li>
          <li><a className="dropdown-item" href="#">{t('specialty_chemicals')}</a></li>
          <li><a className="dropdown-item" href="#">{t('pellets')}</a></li>
          <li><a className="dropdown-item" href="#">{t('dc_granules')}</a></li>
          <li><a className="dropdown-item" href="#">{t('herbal_extracts')}</a></li>
          <li><a className="dropdown-item" href="#">{t('finished_formulations')}</a></li>
          <li><a className="dropdown-item" href="#">{t('cosmetics')}</a></li>
          <li><a className="dropdown-item" href="#">{t('antioxidant_products')}</a></li>
        </ul>
      </li>
      <li className="nav-item dropdown">
        <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          {t('quality')}
        </a>
        <ul className="dropdown-menu">
          <li><a className="dropdown-item" href="#">{t('regulatory_services')}</a></li>
          <li><a className="dropdown-item" href="#">{t('quality_assurance')}</a></li>
          <li><a className="dropdown-item" href="#">{t('quality_control')}</a></li>
          <li><a className="dropdown-item" href="#">{t('quality_policy')}</a></li>
        </ul>
      </li>
      <li className="nav-item">
        <a className="nav-link" href="#">{t('logistics')}</a>
      </li>
      <li className="nav-item">
        <a className="nav-link" href="#">{t('crs')}</a>
      </li>
      <li className="nav-item dropdown">
        <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          {t('news')}
        </a>
        <ul className="dropdown-menu">
          <li><a className="dropdown-item" href="#">{t('news')}</a></li>
          <li><a className="dropdown-item" href="#">{t('blogs')}</a></li>
          <li><a className="dropdown-item" href="#">{t('event_gallery')}</a></li>
        </ul>
      </li>
      <li className="nav-item dropdown">
        <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          {t('career')}
        </a>
        <ul className="dropdown-menu">
          <li><a className="dropdown-item" href="#">{t('human_resources')}</a></li>
          <li><a className="dropdown-item" href="#">{t('hr_articles')}</a></li>
          <li><a className="dropdown-item" href="#">{t('work_with_oceanic')}</a></li>
        </ul>
      </li>
      <li className="nav-item">
        <a className="nav-link" href="#">{t('contact_us')}</a>
      </li>
      <li className="nav-item dropdown">
                <i
                  className="fas fa-bars nav-link"
                  style={{ cursor: 'pointer', marginTop: '14px', marginRight: '10px' ,marginLeft : '20px'  }}
                  onClick={toggleMenuDropdown}
                ></i>
                {showMenuDropdown && (
                  <div className="Main-Manu">
                  <ul className="dropdown-menu show">
                    <li><a className="dropdown-item" href="#"><i className="fas fa-user-shield"></i> {t('Admin')}</a></li>
                    <li><a className="dropdown-item" href="#"><i className="fas fa-map-signs"></i> {t('Guided Tour')}</a></li>
                  </ul>
                  </div>
                )}
              </li>
    </ul>            
              {/* Add other navigation items similarly... */}
            </ul>

            {/* Language Dropdown */}
            <div className="form-container">
              <form className="d-flex" role="search">
                <div className="dropdown">
                  <button
                    className="Nav_bar_lag btn dropdown-toggle"
                    type="button"
                    id="languageDropdown"
                    data-bs-toggle="dropdown"
                    aria-haspopup="true"
                    aria-expanded="false"
                  >
                    {i18n.language === 'en' ? 'English' : 'Japanese'}
                  </button>
                  <div className="dropdown-menu" aria-labelledby="languageDropdown">
                    <a className="dropdown-item" href="#" onClick={() => selectLanguage('en')}>English</a>
                    <a className="dropdown-item" href="#" onClick={() => selectLanguage('ja')}>Japanese</a>
                  </div>
                </div>
                <i
                  className="fas fa-search ml-2"
                  style={{ cursor: 'pointer', marginRight: '20px', marginTop: '35px'  }}
                  onClick={openModal}
                ></i>
                 {/* Menu Icon with Dropdown */}
            
              </form>
            </div>
          </div>
        </div>
      </nav>

      {/* Modal Popup */}
      <Modal show={showModal} onHide={closeModal}   dialogClassName="mt-0" >
        <Modal.Body>
          <div className="d-flex align-items-center">
            <input
              type="text"
              className="form-control me-2"
              placeholder={t('Search...')}
              style={{ flex: '1'  }}
            />
            <Button  variant="secondary" className="search_nav">
              {t('Search')}
            </Button>
            <Button  variant="link" onClick={closeModal} style={{ fontSize: '1.5rem', color: 'white' , marginTop : 20 }}>
              <i className="fas fa-times"></i>
            </Button>
          </div>
        </Modal.Body>
      </Modal>
    </>
  );
}

export default NavBar;
