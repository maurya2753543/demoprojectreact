import React, { useState } from 'react';
import emailjs from 'emailjs-com'; // Import EmailJS
import './ChatPopup.css'; // Assuming you have a separate CSS file for styling
import { toast, ToastContainer } from 'react-toastify'; // Import toastify
import 'react-toastify/dist/ReactToastify.css'; // Import toastify styles

const ChatNot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [errors, setErrors] = useState({ name: '', email: '' });
  const [isSubmitting, setIsSubmitting] = useState(false); // For loading state

  const togglePopup = () => {
    setIsOpen(!isOpen);
  };

  const closePopup = () => {
    setIsOpen(false);
  };

  // Validation logic
  const validateEmail = (email) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  };

  const handleNameChange = (e) => {
    setName(e.target.value);
    setErrors({ ...errors, name: e.target.value ? '' : 'Name is required' });
  };

  const handleEmailChange = (e) => {
    const emailValue = e.target.value;
    setEmail(emailValue);
    let emailError = '';
    if (!emailValue) {
      emailError = 'Email is required';
    } else if (!validateEmail(emailValue)) {
      emailError = 'Invalid email address';
    }
    setErrors({ ...errors, email: emailError });
  };

  const handleMessageChange = (e) => {
    setMessage(e.target.value);
  };

  // Check if the form is valid
  const isFormValid = name && !errors.name && email && !errors.email && message;

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!isFormValid) return;

    setIsSubmitting(true); // Set loading state

    // EmailJS service
    const templateParams = {
      user_name: name,
      user_email: email,
      message: message,
    };

    // Replace with your EmailJS service ID, template ID, and user ID
    emailjs
      .send('service_ndzw3dp', 'template_h43ct9j', templateParams, 'j9IeoZw8w6Mkpkxl6')
      .then((response) => {
        console.log('Email sent successfully!', response);
        setIsSubmitting(false);
        setName(''); // Clear form fields
        setEmail('');
        setMessage('');
        closePopup(); // Close the popup
        toast.success('Message sent successfully!'); // Show success toast
      })
      .catch((error) => {
        console.error('Error sending email:', error);
        setIsSubmitting(false);
        toast.error('Error sending message. Please try again.'); // Show error toast
      });
  };

  return (
    <>
      {/* Icon to open the popup */}
      <div className="chat-icon" onClick={togglePopup}>
        <img src="/image/image_bot-modified.png" alt="Chat Icon" />
      </div>

      {/* Popup content */}
      {isOpen && (
        <div className="chat-popup">
          <div className="popup-header">
            <header className="header-row">
              {/* Logo on the left */}
              <span className="sqico-user hide_fontico logo-container">
                <img
                  src="https://static.zohocdn.com/salesiq/images/logo_Zg8I0qSkbAqR2WFHt3p6CTuqpyXMFPubPcD2OT02zFN43Cy9FUNNG3NEPhM_Q1qe_.png?nps=202"
                  height="49"
                  width="49"
                  id="complogo"
                  className="cmn_mdl siq-company-logo"
                />
                <canvas
                  width="100"
                  height="100"
                  id="blur_userbg"
                  className="blur_userbg"
                ></canvas>
              </span>

              {/* Title in the center */}
              <div className="header-title">
                <div className="txtelips">Leave a message</div>
              </div>

              {/* Close button on the right */}
              <button
                className="close-button"
                onClick={closePopup}
                aria-label="Close chat popup"
              >
                &times;
              </button>
            </header>

            {/* Popup content */}
            <section className="popup-body">
              <div custom="name" inputmode="text" customid="siq_name">
                <input
                  type="text"
                  id="visname"
                  placeholder="Enter your name"
                  className="siq-input-text-box"
                  value={name}
                  onChange={handleNameChange}
                />
                {errors.name && <div className="error-message">{errors.name}</div>}
              </div>
              <div custom="email" customid="siq_email">
                <input
                  type="text"
                  id="visemail"
                  className="siq-input-text-box"
                  placeholder="Enter your email address"
                  value={email}
                  onChange={handleEmailChange}
                />
                {errors.email && <div className="error-message">{errors.email}</div>}
              </div>
              <div className="msgbox">
                <textarea
                  placeholder="Type your message here and click 'Submit'"
                  className="msgarea"
                  id="msgarea"
                  value={message}
                  onChange={handleMessageChange}
                ></textarea>
              </div>
            </section>

            {/* Footer with send icon and submit button */}
            <footer className="popup-footer">
              <button
                className="siq-send-button"
                disabled={!isFormValid || isSubmitting}
                onClick={handleSubmit}
              >
                <i className="fa fa-paper-plane"></i> Submit
              </button>
            </footer>
          </div>
        </div>
      )}

      {/* Toast Container */}
      <ToastContainer />
    </>
  );
};

export default ChatNot;
