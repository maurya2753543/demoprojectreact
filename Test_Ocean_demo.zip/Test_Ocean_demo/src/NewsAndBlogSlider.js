import React from 'react';
import Slider from 'react-slick';
import './NewsAndBlogSlider.css'; // Import your CSS file for styling
import {Button } from 'react-bootstrap'; // Import Modal and Button from react-bootstrap


// Full URLs for images
const newsData = [
  {
    date: "18\nNov 2017", // Add \n for a line break
    imgSrc: "https://oceanicpharmachem.com/upload/blog/listing_image/medium/1550146292.Food_additives_in_food_processing.jpg",
    description: "Food additives in food processing",
    link: "https://oceanicpharmachem.com/blogs-detail/food-additives-in-food-processing"
  },
  {
    date: "12\nNov 2017", // Add \n for a line break
    imgSrc: "https://oceanicpharmachem.com/upload/blog/listing_image/medium/1573730283.blog-small.jpg",
    description: "Pharmaceutical products manufacturing",
    link: "https://oceanicpharmachem.com/blogs-detail/pharmaceutical-products-manufacturing"
  },
  {
    date: "1\nNov 2017", // Add \n for a line break
    imgSrc: "https://oceanicpharmachem.com/upload/blog/listing_image/medium/1550747774.Eisai%E2%80%99s_Next_Mid-Term_Biz_Plan_Will_Show_New_Twist_to_Generic_Operations.jpg",
    description: "Modern chemicals in use",
    link: "https://oceanicpharmachem.com/blogs-detail/modern-chemicals-in-use"
  },
  {
    date: "13\nDec 2017", // Add \n for a line break
    imgSrc: "https://oceanicpharmachem.com/upload/blog/listing_image/medium/1582179886.Oceanic-Blog-S.jpg",
    description: "Innovations in pharma",
    link: "https://oceanicpharmachem.com/blogs-detail/innovations-in-pharma"
  },
  {
    date: "18\nJuly 2023", // Add \n for a line break
    imgSrc: "https://oceanicpharmachem.com/upload/blog/listing_image/medium/1636366111.global_supplies_in_2021.jpg",
    description: "Safety in chemical use",
    link: "https://oceanicpharmachem.com/blogs-detail/safety-in-chemical-use"
  },
  {
    date: "18\nNov 2018", // Add \n for a line break
    imgSrc: "https://oceanicpharmachem.com/upload/blog/listing_image/medium/1582179886.Oceanic-Blog-S.jpg",
    description: "Innovations in pharma",
    link: "https://oceanicpharmachem.com/blogs-detail/innovations-in-pharma"
  },
  {
    date: "24\nJan 2013", // Add \n for a line break
    imgSrc: "https://oceanicpharmachem.com/upload/blog/listing_image/medium/1636366111.global_supplies_in_2021.jpg",
    description: "Safety in chemical use",
    link: "https://oceanicpharmachem.com/blogs-detail/safety-in-chemical-use"
  },
  {
    date: "14\nSep 2015", // Add \n for a line break
    imgSrc: "https://oceanicpharmachem.com/upload/blog/listing_image/medium/1582179886.Oceanic-Blog-S.jpg",
    description: "Innovations in pharma",
    link: "https://oceanicpharmachem.com/blogs-detail/innovations-in-pharma"
  },
  {
    date: "14\nAug 2015", // Add \n for a line break
    imgSrc: "https://oceanicpharmachem.com/upload/blog/listing_image/medium/1636366111.global_supplies_in_2021.jpg",
    description: "Safety in chemical use",
    link: "https://oceanicpharmachem.com/blogs-detail/safety-in-chemical-use"
  },
  // Add more slides here if needed...
];

const NewsAndBlogSlider = () => {
    const settings = {
        dots: false,
        infinite: true,
        speed: 300,
        slidesToShow: 3,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 3000,
        arrows: false, // Hide side arrows
        responsive: [
          {
            breakpoint: 1024,
            settings: {
              slidesToShow: 2,
              slidesToScroll: 1,
              infinite: true,
              dots: true
            }
          },
          {
            breakpoint: 600,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1
            }
          }
        ]
      };
      

  return (
    <div className="news-container">
      <h2>News & <span className="news-title">Blogs</span></h2>
      <Slider {...settings}>
        {newsData.map((item, index) => (
          <div key={index} className="news-item">
            <div className="blog-main-img">
              <div className="blog-main-date"><p>{item.date}</p></div>
              <img alt={item.description} src={item.imgSrc} className="img-fluid" />
            </div>
            <div className="blog-main-para">{item.description}</div>
            <Button className='News_more_btn'  href={item.link} target="_blank" rel="noopener noreferrer">Read More</Button>
          </div>
        ))}
      </Slider>
    </div>
  );
};

export default NewsAndBlogSlider;
