// src/components/EventGallery.js

import React from 'react';
import Slider from 'react-slick';
import './EventGallery.css'; // Make sure you have styles for .event-gallery and .event-item

// Full URLs for images
const imageBaseURL = 'https://oceanicpharmachem.com/upload/photo_gallery/medium/';
const eventData = [
    { imgSrc: `${imageBaseURL}15510976802014-07-01-14.10.34.jpg`, alt: 'Interphex Japan 2014', caption: 'Interphex Japan 2014', link: 'event-photo-gallery/11' },
    { imgSrc: `${imageBaseURL}15510978502014-05-23-12.41.291.jpg`, alt: 'IPHEX India 2014', caption: 'IPHEX India 2014', link: 'event-photo-gallery/12' },
    { imgSrc: `${imageBaseURL}1666357853A7R04510.jpg`, alt: 'CPHI America Sponsorship', caption: 'CPHI America Sponsorship', link: 'event-photo-gallery/13' },
    { imgSrc: `${imageBaseURL}1623158889002.jpeg`, alt: 'Immunity Booster Distributed 2021', caption: 'Immunity Booster Distributed 2021', link: 'event-photo-gallery/14' },
    { imgSrc: `${imageBaseURL}15676679651.jpg`, alt: 'Evening with Japanese Sake', caption: 'Evening with Japanese Sake', link: 'event-photo-gallery/16' },
    { imgSrc: `${imageBaseURL}1566215715IMG_7221.JPG`, alt: 'CPHI Europe 2019', caption: 'CPHI Europe 2019', link: 'event-photo-gallery/18' },
    { imgSrc: `${imageBaseURL}1623159336001.jpeg`, alt: 'Oxygen Concentrator Distributed 2021', caption: 'Oxygen Concentrator Distributed 2021', link: 'event-photo-gallery/19' },
    { imgSrc: `${imageBaseURL}15510976802014-07-01-14.10.34.jpg`, alt: 'Interphex Japan 2014', caption: 'Interphex Japan 2014', link: 'event-photo-gallery/11' },
    { imgSrc: `${imageBaseURL}15510978502014-05-23-12.41.291.jpg`, alt: 'IPHEX India 2014', caption: 'IPHEX India 2014', link: 'event-photo-gallery/12' },
    { imgSrc: `${imageBaseURL}157785731113.jpg`, alt: '31st Dec 2019 Party Celebrations', caption: '31st Dec 2019 Party Celebrations', link: 'event-photo-gallery/14' },
    { imgSrc: `${imageBaseURL}1623157835001.jpeg`, alt: 'Mask Distributed 2021', caption: 'Mask Distributed 2021', link: 'event-photo-gallery/15' },
    { imgSrc: `${imageBaseURL}15676679651.jpg`, alt: 'Evening with Japanese Sake', caption: 'Evening with Japanese Sake', link: 'event-photo-gallery/16' },
    { imgSrc: `${imageBaseURL}1566215508DSC_6789.JPG`, alt: 'CPHI World Wide 2015', caption: 'CPHI World Wide 2015', link: 'event-photo-gallery/20' },
];

const EventGallery = () => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 250,
    slidesToShow: 5,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000,
    arrows: true, // Hide side arrows
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
          infinite: true,
          dots: true
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
    ]
  };

  return (
    <div className="event-gallery">
      <h2>Event <span className="gallery-title">Gallery</span></h2>
      <Slider {...settings}>
        {eventData.map((item, index) => (
          <div key={index} className="event-item">
            <img
              src={item.imgSrc}
              alt={item.alt}
              className="img-fluid"
            />
            <p className="event-caption">{item.caption}</p>
          </div>
        ))}
      </Slider>
    </div>
  );
};

export default EventGallery;
