import React from 'react';
import Slider from 'react-slick';
import './CounterCarousel.css';
import { PrevArrow, NextArrow } from './CustomArrows'; // Adjust the path as needed

// Full URLs for images
const imageBaseURL = 'https://oceanicpharmachem.com/site/views/images/';
const counterData = [
  { imgSrc: `${imageBaseURL}icon_product.png`, count: 5000, text: 'Products', suffix: '+' },
  { imgSrc: `${imageBaseURL}icon_modules.png`, count: 25, text: 'Niche Molecules Developed', suffix: '+' },
  { imgSrc: `${imageBaseURL}icon_emp.png`, count: 60, text: 'Our Strength', suffix: '+' },
  { imgSrc: `${imageBaseURL}icon_industry.png`, count: 11, text: 'Industry Segments', suffix: '' },
  { imgSrc: `${imageBaseURL}icon_expertise.png`, count: 40, text: 'Years of Expertise', suffix: '+' },
  { imgSrc: `${imageBaseURL}icon_countries.png`, count: 52, text: 'Countries & Expanding', suffix: '' },
  { imgSrc: `${imageBaseURL}icon_audit.png`, count: 100, text: 'Audits Conducted', suffix: '+' },
];

const CounterCarousel = () => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 150,
    slidesToShow: 4,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 1000,
    prevArrow: <PrevArrow />,
    nextArrow: <NextArrow />,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          infinite: true,
          dots: true
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
    ]
  };

  return (
    <>
    <h2 className="new_title">Why <span className="red">Choose</span> us</h2>
    <div className="counter-carousel-container">
      <Slider {...settings}>
        {counterData.map((item, index) => (
          <div key={index} className="counter-item">
            <div className="counter-box">
              <div className="thumb_cor">
                <img src={item.imgSrc} alt={item.text} />
              </div>
              <h2>
                <span className="counter">{item.count}</span>
                {item.suffix}
              </h2>
              <span className="desc">{item.text}</span>
            </div>
          </div>
        ))}
      </Slider>
    </div>
    </>
 
  );
};

export default CounterCarousel;
