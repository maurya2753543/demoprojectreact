// src/i18n.js
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

// Import translations
const resources = {
  en: {
    translation: {
      "home": "Home",
      "about_us": "ABOUT US",
      "company_at_a_glance": "COMPANY AT A GLANCE",
      "the_beginnings": "THE BEGINNINGS",
      "global_presence": "GLOBAL PRESENCE",
      "whats_happening_nowadays": "WHATS HAPPENING NOWADAYS",
      "our_strong_presence": "OUR STRONG PRESENCE",
      "products": "PRODUCTS",
      "active_pharmaceutical_ingredient": "ACTIVE PHARMACEUTICAL INGREDIENT (APIS)",
      "veterinary_products": "VETERINARY PRODUCTS",
      "impurities": "IMPURITIES",
      "bulk_drug_intermediates": "BULK DRUG INTERMEDIATES",
      "specialty_chemicals": "SPECIALTY CHEMICALS",
      "pellets": "PELLETS",
      "dc_granules": "DC GRANULES",
      "herbal_extracts": "HERBAL EXTRACTS",
      "finished_formulations": "FINISHED FORMULATIONS",
      "cosmetics": "COSMETICS",
      "antioxidant_products": "ANTIOXIDANT PRODUCTS",
      "quality": "QUALITY",
      "regulatory_services": "REGULATORY SERVICES",
      "quality_assurance": "QUALITY ASSURANCE",
      "quality_control": "QUALITY CONTROL",
      "quality_policy": "QUALITY POLICY",
      "logistics": "LOGISTICS",
      "crs": "CRS",
      "news": "NEWS",
      "blogs": "BLOGS",
      "event_gallery": "EVENT GALLERY",
      "career": "CAREER",
      "human_resources": "HUMAN RESOURCES",
      "hr_articles": "HR ARTICLES",
      "work_with_oceanic": "WORK WITH OCEANIC",
      "contact_us": "CONTACT US",
      // Add all other translations here...
    }
  },
  ja: {
    translation: {
      "home": "ホーム",
      "about_us": "私たちについて",
      "company_at_a_glance": "会社概要",
      "the_beginnings": "始まり",
      "global_presence": "グローバルな存在",
      "whats_happening_nowadays": "最近の出来事",
      "our_strong_presence": "私たちの強力な存在",
      "products": "製品",
      "active_pharmaceutical_ingredient": "アクティブ医薬品成分 (API)",
      "veterinary_products": "獣医製品",
      "impurities": "不純物",
      "bulk_drug_intermediates": "バルク医薬中間体",
      "specialty_chemicals": "特殊化学品",
      "pellets": "ペレット",
      "dc_granules": "DCグラニュール",
      "herbal_extracts": "ハーブ抽出物",
      "finished_formulations": "完成製剤",
      "cosmetics": "化粧品",
      "antioxidant_products": "抗酸化製品",
      "quality": "品質",
      "regulatory_services": "規制サービス",
      "quality_assurance": "品質保証",
      "quality_control": "品質管理",
      "quality_policy": "品質方針",
      "logistics": "物流",
      "crs": "CRS",
      "news": "ニュース",
      "blogs": "ブログ",
      "event_gallery": "イベントギャラリー",
      "career": "キャリア",
      "human_resources": "人事",
      "hr_articles": "HR記事",
      "work_with_oceanic": "オーシャニックで働く",
      "contact_us": "お問い合わせ",
      // Add all other translations here...
    }
  }
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: 'en', // default language
    interpolation: {
      escapeValue: false // react already safes from xss
    }
  });

export default i18n;
