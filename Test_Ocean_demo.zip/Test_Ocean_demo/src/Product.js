import React from 'react';
import  './Product.css';
import '@fortawesome/fontawesome-free/css/all.min.css'; // Import FontAwesome

const products = [
  { id: 'productred100', title: 'Active Pharmaceutical Ingredients (APIs)', link: 'https://oceanicpharmachem.com/category/active-pharmaceutical-ingredients-apis-' },
  { id: 'productred101', title: 'Veterinary Products', link: 'https://oceanicpharmachem.com/category/veterinary-products' },
  { id: 'productred102', title: 'Impurities', link: 'https://oceanicpharmachem.com/category/impurities' },
  { id: 'productred103', title: 'Bulk Drug Intermediates', link: 'https://oceanicpharmachem.com/category/bulk-drug-intermediates' },
  { id: 'productred104', title: 'Antioxidant Products', link: 'https://oceanicpharmachem.com/category/antioxidant-products' },
  { id: 'productred105', title: 'Specialty Chemicals', link: 'https://oceanicpharmachem.com/category/specialty-chemicals' },
  { id: 'productred106', title: 'DC Granules', link: 'https://oceanicpharmachem.com/category/dc-granules' },
  { id: 'productred107', title: 'Cosmetic Ingredients', link: 'https://oceanicpharmachem.com/category/cosmetic-ingredients' },
  { id: 'productred108', title: 'Nutraceutical Ingredients', link: 'https://oceanicpharmachem.com/category/nutraceutical-ingredients' },
  { id: 'productred109', title: 'Pharmaceutical Intermediates', link: 'https://oceanicpharmachem.com/category/pharmaceutical-intermediates' },
  { id: 'productred110', title: 'Excipients', link: 'https://oceanicpharmachem.com/category/excipients' },
];

const Product = () => {
  return (
    <div className="product-gray-block">
      <div className="container">
        <div className="wow slideInUp new_title" data-wow-delay="0.1s" data-wow-duration="1.2s" style={{ visibility: 'visible', animationDuration: '1.2s', animationDelay: '0.1s', animationName: 'slideInUp' }}>
          <h3 className="new_title_inside_product" data-wow-delay="0.2s" data-wow-duration="1.2s" style={{ visibility: 'visible', animationDuration: '1.2s', animationDelay: '0.2s', animationName: 'slideInUp' }}>
            Our <span className="red">Products</span>
          </h3>
        </div>       
        <ul className="product-list">
  {products.map((product, index) => (
    <li
      key={product.id}
      className={`product-item ${product.id} wow fadeInLeft`}
      data-wow-delay={`${index * 0.1}s`}
      style={{ visibility: 'visible', animationDelay: `${index * 0.1}s`, animationName: 'fadeInLeft' }}
    >
      <div className="produ_main">
        <a href={product.link}>
          <div className={`product-content ${product.id}`}>
            {/* Icon */}
            <span className="produ_icon">
              <i className="fa fa-icon-example"></i> {/* Replace with your specific icon */}
            </span>
            {/* Title */}
          
          </div>
          <h3 className="product-title">
              {product.title}
              <span className="produ_arrow">
                <i className="fa fa-angle-double-right"></i>
              </span>
            </h3>
        </a>
      </div>
    </li>
  ))}
</ul>

      </div>
    </div>
  );
};

export default Product;
