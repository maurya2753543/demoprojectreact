import React from 'react';
import './Footer.css'; // Assuming you have a CSS file for styling

const Footer = () => {
  return (
    <div className="footer">
      <div className="container">
        <div className="row">
          {/* Column 1: Corporate Information */}
          <div className="col-md-3 col-sm-6">
            <h3>Corporate Information</h3>
            <ul>
              <li><a href="https://oceanicpharmachem.com/about-us#about">Company at a Glance</a></li>
              <li><a href="https://oceanicpharmachem.com/about-us#presence">The beginnings</a></li>
              <li><a href="https://oceanicpharmachem.com/about-us#presence">Global presence</a></li>
              <li><a href="https://oceanicpharmachem.com/about-us#happening">What’s happening nowadays</a></li>
              <li><a href="https://oceanicpharmachem.com/about-us#happening">Our strong presence</a></li>
            </ul>
            <h3>Get Social</h3>
            <ul className="social-m">
              <li><a href="https://www.youtube.com/channel/UC2m6rHI9L7BL0o7sEaRkzHQ/featured" target="_blank" rel="noopener noreferrer" className="fab fa-youtube fa-10x"></a></li>
              <li><a href="https://www.linkedin.com/company/oceanic-pharmachem-pvt-ltd/" target="_blank" rel="noopener noreferrer" className="fab fa-linkedin fa-10x"></a></li>
            </ul>
          </div>

          {/* Column 2: Quality */}
          <div className="col-md-3 col-sm-6">
            <h3>Quality</h3>
            <ul>
              <li><a href="https://oceanicpharmachem.com/quality/regulatory-services">Regulatory Services</a></li>
              <li><a href="https://oceanicpharmachem.com/quality/quality-assurance-">Quality Assurance</a></li>
              <li><a href="https://oceanicpharmachem.com/quality/quality-control-">Quality Control</a></li>
              <li><a href="https://oceanicpharmachem.com/quality/quality-policy">Quality Policy</a></li>
            </ul>
          </div>

          {/* Column 3: Products */}
          <div className="col-md-3 col-sm-6">
            <h3>Products</h3>
            <ul>
              <li><a href="https://oceanicpharmachem.com/category/active-pharmaceutical-ingredients-apis-">Active Pharmaceutical Ingredients (APIs)</a></li>
              <li><a href="https://oceanicpharmachem.com/category/veterinary-products">Veterinary Products</a></li>
              <li><a href="https://oceanicpharmachem.com/category/impurities">Impurities</a></li>
              <li><a href="https://oceanicpharmachem.com/category/bulk-drug-intermediates">Bulk Drug Intermediates</a></li>
              <li><a href="https://oceanicpharmachem.com/category/specialty-chemicals">Specialty Chemicals</a></li>
              <li><a href="https://oceanicpharmachem.com/category/pellets">Pellets</a></li>
              <li><a href="https://oceanicpharmachem.com/category/dc-granules">DC Granules</a></li>
              <li><a href="https://oceanicpharmachem.com/category/herbal-extracts">Herbal Extracts</a></li>
              <li><a href="https://oceanicpharmachem.com/category/finished-formulations">Finished Formulations</a></li>
              <li><a href="https://oceanicpharmachem.com/category/cosmetics">Cosmetics</a></li>
              <li><a href="https://oceanicpharmachem.com/category/antioxidant-products">Antioxidant Products</a></li>
            </ul>
          </div>

          {/* Column 4: Quick Links */}
          <div className="col-md-3 col-sm-6">
            <h3>Quick Links</h3>
            <ul>
              <li><a href="https://oceanicpharmachem.com/news">News</a></li>
              <li><a href="https://oceanicpharmachem.com/blogs">Blogs</a></li>
              <li><a href="https://oceanicpharmachem.com/csr">CSR</a></li>
              <li><a href="https://oceanicpharmachem.com/logistic-management-system">Logistic</a></li>
              <li><a href="https://oceanicpharmachem.com/human-resources">Career</a></li>
              <li><a href="https://oceanicpharmachem.com/contact">Contact Us</a></li>
            </ul>
          </div>
        </div>

        {/* Footer Bottom */}
        <div className='footer_div'>
        <div className="footer-bottom">
          <div className="footer-copleft">
            <span className="footer-copright">
                <div className='div-footer'>
                Copyright © 2014 -2020. Oceanic Pharmachem Pvt. Ltd.. All rights reserved.
                </div>

            <a href="https://oceanicpharmachem.com/sitemap">Sitemap</a>
            <a href="https://oceanicpharmachem.com/discliamer">Disclaimer</a>
            <a href="#">Enquiry</a>
          </span>
          </div>
        
        </div>
        </div>
      
      </div>
    </div>
  );
};

export default Footer;
